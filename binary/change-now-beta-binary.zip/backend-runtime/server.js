require('dotenv').config();

const express = require('express');
const authRouter = require("./routes/auth");
const exerciseRoutes = require("./routes/exerciseRoutes");
const workoutRouter = require("./routes/workouts");
const app = express();
//my browser requires whitelisted address if api and frontend addresses are different
const cors = require("cors");
const pool = require('./dbconnection');

const isPrivateHostname = (hostname) =>
    hostname === "localhost" ||
    hostname === "127.0.0.1" ||
    hostname === "::1" ||
    /^10\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(hostname) ||
    /^192\.168\.\d{1,3}\.\d{1,3}$/.test(hostname) ||
    /^172\.(1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}$/.test(hostname);

const corsOptions = {
    origin(origin, callback) {
        if (!origin) {
            callback(null, true);
            return;
        }
        if (origin === "https://changenow-ashy.vercel.app") {
            console.log('prod origin parsed');
            return callback (null,true);
        }

        try {
            const parsedOrigin = new URL(origin);
            if (parsedOrigin.protocol === "http:" && isPrivateHostname(parsedOrigin.hostname)) {
                callback(null, true);
                return;
            }
        } catch (error) {
            console.log(`Invalid CORS origin: ${origin}`);
        }

        callback(new Error(`Origin not allowed by CORS: ${origin}`));
    },
    credentials: true,
};

app.use(cors({
    ...corsOptions
}));

app.use(express.json());
app.use("/auth", authRouter);
// Exercise routes are scaffolded separately so the frontend can move to a real
// API contract without changing its object shape later.
app.use("/exercises", exerciseRoutes);
app.use("/workouts", workoutRouter)


//test route
app.get('/', (req, res) => {
    res.send('Gym API is running');
})

//start server
const port = process.env.PORT || 4000;

if (require.main === module) {
    app.listen(port, '', () => {
        console.log(`Server listening on port ${port}`);
    });
}


//get all members test
app.get('/users', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM users ORDER BY id');
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Database error'});
    }
});

module.exports = app;
