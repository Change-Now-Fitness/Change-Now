require('dotenv').config();
const express = require('express');
const authRouter = require("./routes/auth");
const exerciseRoutes = require("./routes/exerciseRoutes");
const workoutRouter = require("./routes/workouts");
const userRouter = require("./routes/user");
const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');
const pool = require('./dbconnection');
const {
    assertValidRuntimeConfig,
    configuredCorsOrigins,
    getRuntimeConfigIssues,
    getCorsOptions,
    getPublicApiUrl,
    shouldTrustProxy,
} = require("./config/runtime");

const app = express();
const cors = require("cors");

//start server
const port = process.env.PORT || 4000;
const host = process.env.HOST || '0.0.0.0';
const publicApiUrl = getPublicApiUrl(port);
const corsOptions = getCorsOptions();
const { warnings: runtimeWarnings } = getRuntimeConfigIssues();

assertValidRuntimeConfig();

app.disable("x-powered-by");
if (shouldTrustProxy) {
    app.set("trust proxy", 1);
}

app.use(cors(corsOptions));

for (const warning of runtimeWarnings) {
    console.warn(`Runtime configuration warning: ${warning}`);
}

const mountApiRouter = (basePath, router) => {
    app.use(basePath, router);
    app.use(`/api${basePath}`, router);
};

const swaggerOptions = {
    definition: {
        openapi: '3.0.0',
        info: {
            title: 'Change Now API Docs', 
            version: '5.10.26'
        },
        servers: [
            {
                url: publicApiUrl,
                description: process.env.NODE_ENV === "production" ? "Production Server" : "Configured API Server"
            }
        ],
    },
    apis: ['routes/auth.js', 'routes/user.js'],
};

const swaggerSpecifications = swaggerJsdoc(swaggerOptions);

app.use(express.json());

app.use('/api-docs',
    swaggerUi.serve, 
    swaggerUi.setup(swaggerSpecifications, {explorer: true})
);

mountApiRouter("/auth", authRouter);
mountApiRouter("/user", userRouter);
// Exercise routes are scaffolded separately so the frontend can move to a real
// API contract without changing its object shape later.
mountApiRouter("/exercises", exerciseRoutes);
mountApiRouter("/workouts", workoutRouter);

app.get('/', (req, res) => {
    res.json({
        name: "ChangeNow API",
        status: "ok",
        docs: "/api-docs",
        health: "/health",
        ready: "/ready",
        publicApiUrl,
        allowedCorsOrigins: configuredCorsOrigins,
        routeAliases: {
            auth: ["/auth", "/api/auth"],
            user: ["/user", "/api/user"],
            exercises: ["/exercises", "/api/exercises"],
            workouts: ["/workouts", "/api/workouts"],
        },
    });
});

app.get(['/health', '/api/health'], (req, res) => {
    res.status(200).json({
        status: "ok",
        service: "backend",
        timestamp: new Date().toISOString(),
        uptimeSeconds: Math.round(process.uptime()),
    });
});

app.get(['/ready', '/api/ready'], async (req, res) => {
    try {
        await pool.query('SELECT 1');
        res.status(200).json({
            status: "ok",
            service: "backend",
            database: "ok",
            timestamp: new Date().toISOString(),
        });
    } catch (error) {
        console.error('Readiness check failed:', error);
        res.status(503).json({
            status: "error",
            service: "backend",
            database: "unavailable",
            timestamp: new Date().toISOString(),
        });
    }
});


if (require.main === module) {
    app.listen(port, host, () => {
        console.log(`Server listening on ${host}:${port}`);
        console.log(`Public API URL: ${publicApiUrl}`);
    });
}


//get all members test
app.get('/users', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM users ORDER BY id');
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Database error'});
    }
});

module.exports = app;
